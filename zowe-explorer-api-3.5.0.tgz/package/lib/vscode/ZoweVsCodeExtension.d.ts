/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import * as vscode from "vscode";
import { ProfilesCache } from "../profiles/ProfilesCache";
import * as imperative from "@zowe/imperative";
import type { PromptCredentialsOptions } from "./doc/PromptCredentials";
import { Types } from "../Types";
import type { BaseProfileAuthOptions } from "./doc/BaseProfileAuth";
/**
 * Collection of utility functions for writing Zowe Explorer VS Code extensions.
 */
export declare class ZoweVsCodeExtension {
    static get workspaceRoot(): vscode.WorkspaceFolder | undefined;
    static get onProfileUpdatedEmitter(): vscode.EventEmitter<imperative.IProfileLoaded>;
    static get onProfileUpdated(): vscode.Event<imperative.IProfileLoaded>;
    /**
     * Get custom logging path if one is defined in VS Code settings.
     */
    static get customLoggingPath(): string | undefined;
    /**
     * @param {string} [requiredVersion] Optional semver string specifying the minimal required version
     * of Zowe Explorer that needs to be installed for the API to be usable to the client.
     * @returns an initialized instance `IApiRegisterClient` that extenders can use
     * to access the Zowe Explorer APIs or `undefined`. Also `undefined` if requiredVersion
     * is larger than the version of Zowe Explorer found.
     */
    static getZoweExplorerApi(requiredVersion?: string): Types.IApiRegisterClient;
    /**
     * Helper function to standardize the way we ask the user for credentials that updates ProfilesCache
     * @param options Set of options to use when prompting for credentials
     * @returns Instance of imperative.IProfileLoaded containing information about the updated profile
     */
    static updateCredentials(options: PromptCredentialsOptions.ComplexOptions, apiRegister: Types.IApiRegisterClient): Promise<imperative.IProfileLoaded>;
    /**
     * Trigger a login operation with the merged contents between the service profile and the base profile.
     * If the connection details (host:port) do not match (service vs base), the token will be stored in the service profile.
     * If there is no API registered for the profile type, this method defaults the login behavior to that of the APIML.
     * @deprecated Use `ZoweVsCodeExtension.ssoLogin` instead
     * @param serviceProfile Profile to be used for login purposes (either the name of the IProfileLoaded instance)
     * @param loginTokenType The tokenType value for compatibility purposes
     * @param node The node for compatibility purposes
     * @param zeRegister The ZoweExplorerApiRegister instance for compatibility purposes
     * @param zeProfiles The Zowe Explorer "Profiles.ts" instance for compatibility purposes
     */
    static loginWithBaseProfile(serviceProfile: string | imperative.IProfileLoaded, loginTokenType?: string, node?: Types.IZoweNodeType, zeRegister?: Types.IApiRegisterClient, // ZoweExplorerApiRegister
    zeProfiles?: ProfilesCache): Promise<boolean>;
    /**
     * Trigger a login operation with the merged contents between the service profile and the base profile.
     * If the connection details (host:port) do not match (service vs base), the token will be stored in the service profile.
     * If there is no API registered for the profile type, this method defaults the login behavior to that of the APIML.
     * @param {BaseProfileAuthOptions} opts Object defining options for base profile authentication
     */
    static ssoLogin(opts: BaseProfileAuthOptions): Promise<boolean>;
    /**
     * Trigger a direct connection login process, not via API ML
     *
     * @param {imperative.IProfileLoaded} [serviceProfile] Instance of profile to be used for obtaining token
     * @param {Types.IApiRegisterClient} [zeRegister] Instance of `IApiRegisterClient`
     * @param {Types.IZoweNodeType} [node] Optional instance of `IZoweNodeType`
     * @returns boolean value of successful login
     */
    static directConnectLogin(serviceProfile: imperative.IProfileLoaded, zeRegister: Types.IApiRegisterClient, node?: Types.IZoweNodeType): Promise<boolean>;
    /**
     * Trigger a logout operation with the merged contents between the service profile and the base profile.
     *  If the connection details (host:port) do not match (service vs base), the token will be removed from the service profile.
     *  If there is no API registered for the profile type, this method defaults the logout behavior to that of the APIML.
     * @deprecated Use `ZoweVsCodeExtension.ssoLogout` instead
     * @param serviceProfile Profile to be used for logout purposes (either the name of the IProfileLoaded instance)
     * @param zeRegister The ZoweExplorerApiRegister instance for compatibility purposes
     * @param zeProfiles The Zowe Explorer "Profiles.ts" instance for compatibility purposes
     */
    static logoutWithBaseProfile(serviceProfile: string | imperative.IProfileLoaded, zeRegister?: Types.IApiRegisterClient, // ZoweExplorerApiRegister
    zeProfiles?: ProfilesCache): Promise<boolean>;
    /**
     * Trigger a logout operation with the merged contents between the service profile and the base profile.
     *  If the connection details (host:port) do not match (service vs base), the token will be removed from the service profile.
     *  If there is no API registered for the profile type, this method defaults the logout behavior to that of the APIML.
     * @param {BaseProfileAuthOptions} opts Object defining options for base profile authentication
     */
    static ssoLogout(opts: BaseProfileAuthOptions): Promise<boolean>;
    /**
     * Trigger a direct connection logout process, not via API ML
     *
     * @param {imperative.IProfileLoaded} [serviceProfile] Instance of profile to be used for retiring token
     * @param {Types.IApiRegisterClient} [zeRegister] Instance of `IApiRegisterClient`
     * @param {Types.IZoweNodeType} [node] Optional instance of `IZoweNodeType`
     * @returns boolean value of successful logout
     */
    static directConnectLogout(serviceProfile: imperative.IProfileLoaded, zeRegister: Types.IApiRegisterClient, node?: Types.IZoweNodeType): Promise<boolean>;
    /**
     * Prompt users through process of creating a Zowe team configuration file including Zowe Explorer registered types
     * Upon successful completion, editor will open team configuration file.
     *
     * @returns void
     */
    static createTeamConfiguration(): Promise<void>;
    static openConfigFile(filePath: string): Promise<void>;
    static getConfigLayers(): Promise<imperative.IConfigLayer[]>;
    /**
     * This method is intended to be used for authentication (login, logout) purposes
     *
     * Note: this method calls the `getServiceProfileForAuthPurposes()` which creates a new instance of the ProfileInfo APIs
     *          Be aware that any non-saved updates will not be considered here.
     * @param {BaseProfileAuthOptions} opts Object defining options for base profile authentication
     * @returns The IProfileLoaded with tokenType and tokenValue
     */
    private static getServiceProfile;
    /**
     * This method is intended to be used for authentication (login, logout) purposes
     *
     * Note: this method calls the `getProfileInfo()` which creates a new instance of the ProfileInfo APIs
     *          Be aware that any non-saved updates will not be considered here.
     * @param cache Instance of ProfilesCache already initialized
     * @param profile Name of the profile to load the IProfileLoaded
     * @returns The IProfileLoaded with tokenType and tokenValue
     */
    private static getServiceProfileForAuthPurposes;
    private static saveCredentials;
    private static promptUserPass;
    private static promptCertificate;
    private static checkExistingConfig;
    private static getConfigLocationPrompt;
    private static createNonSecureProfile;
}
