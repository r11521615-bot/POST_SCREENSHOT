/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { Types } from "../../Types";
import { Disposable, Event, ExtensionContext, ViewColumn, WebviewPanel, WebviewView } from "vscode";
export type WebViewOpts = {
    /** Callback function that is called when the extension has received a message from the webview. */
    onDidReceiveMessage?: (message: object) => void | Promise<void>;
    /** Retains context of the webview even after it is hidden. */
    retainContext?: boolean;
    /** Whether the webview should be prepared for a WebviewViewProvider. */
    isView?: boolean;
    /** Allow evaluation of functions within the webview script code. */
    unsafeEval?: boolean;
    /** Which ViewColumn to open the webview. */
    viewColumn?: ViewColumn;
    /** Optional icon path (string or Uri) for the webview tab. */
    iconPath?: WebviewPanel["iconPath"];
};
export type UriPair = {
    /** The paths for the webview on-disk. */
    disk?: Types.WebviewUris;
    /** The paths for the webview resources, before transformation by the `asWebviewUri` function. */
    resource?: Types.WebviewUris;
};
export declare class WebView {
    protected disposables: Disposable[];
    protected webviewContent: string;
    panel: WebviewPanel;
    view: WebviewView;
    private eventsRegistered;
    private onDisposedEmitter;
    onDisposed: Event<void>;
    protected uris: UriPair;
    private nonce;
    protected title: string;
    protected context: ExtensionContext;
    private webviewOpts;
    /**
     * Constructs a webview for use with bundled assets.
     * The webview entrypoint must be located at src/<webview folder>/dist/<webview-name>/index.js.
     *
     * @param title The title for the new webview
     * @param webviewName The webview name, the same name given to the directory of your webview in the webviews/src directory.
     * @param context The VSCode extension context
     * @param onDidReceiveMessage Event callback: called when messages are received from the webview
     */
    constructor(title: string, webviewName: string, context: ExtensionContext, opts?: WebViewOpts);
    resolveForView(webviewView: WebviewView): void;
    /**
     * Disposes of the webview instance
     */
    dispose(): void;
    /**
     * Pre-processed HTML content that loads the bundled script through the webview.
     */
    get htmlContent(): string;
}
