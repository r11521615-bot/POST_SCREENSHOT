/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { UriPair, WebView } from "./WebView";
import { Event, ExtensionContext } from "vscode";
import type { IZoweTreeNode } from "../../tree";
import type * as imperative from "@zowe/imperative";
import type { IDataSetSource } from "../../dataset";
export declare namespace Table {
    type TreeNodeData = {
        id?: string;
        parentId?: string;
        depth?: number;
        hasChildren?: boolean;
        isExpanded?: boolean;
    };
    type ContentTypes = string | number | boolean | string[] | RowData[] | TreeNodeData | undefined;
    type RowData = Record<string | number, ContentTypes> & {
        children?: RowData[];
        _tree?: TreeNodeData;
    };
    type ColData = RowData;
    type RowInfo = {
        index?: number;
        row: RowData;
    };
    type CallbackTypes = "single-row" | "multi-row" | "column" | "cell" | "no-selection";
    type SingleRowCallback = {
        /** The type of callback */
        typ: "single-row";
        /** The callback function itself - called from within the webview container. */
        fn: (view: Table.View, row: RowInfo) => void | PromiseLike<void>;
    };
    type MultiRowCallback = {
        /** The type of callback */
        typ: "multi-row";
        /** The callback function itself - called from within the webview container. */
        fn: (view: Table.View, rows: Record<number, RowData>) => void | PromiseLike<void>;
    };
    type CellCallback = {
        /** The type of callback */
        typ: "cell";
        /** The callback function itself - called from within the webview container. */
        fn: (view: Table.View, cell: ContentTypes) => void | PromiseLike<void>;
    };
    type ColumnCallback = {
        /** The type of callback */
        typ: "column";
        /** The callback function itself - called from within the webview container. */
        fn: (view: Table.View, col: ColData) => void | PromiseLike<void>;
    };
    type NoSelectionCallback = {
        /** The type of callback */
        typ: "no-selection";
        /** The callback function itself - called from within the webview container. */
        fn: (view: Table.View) => void | PromiseLike<void>;
    };
    type Callback = SingleRowCallback | MultiRowCallback | CellCallback | NoSelectionCallback;
    /** Conditional callback function - whether an action or option should be rendered. */
    type Conditional = ((data: RowData[] | RowData | ContentTypes) => boolean | Promise<boolean>) | string;
    type ActionKind = "primary" | "secondary" | "icon";
    /** Dynamic title function - returns the title based on the selected data. */
    type DynamicTitle = ((data: RowData[] | RowData | ContentTypes) => string | Promise<string>) | string;
    type Action = {
        title: DynamicTitle;
        command: string;
        /** A function that's invoked with row data. It should return `true` if the action can be used on the given row(s). */
        condition?: Conditional;
        /** A function that's invoked with row data. It should return `true` if the action must be hidden from the UI. */
        hideCondition?: Conditional;
        type?: ActionKind;
        callback: Callback;
    };
    type ContextMenuOption = Omit<Action, "type"> & {
        dataType?: CallbackTypes;
    };
    /** @deprecated Use `Action` type instead. */
    type ActionOpts = Action;
    /** @deprecated Use `ContextMenuOption` type instead. */
    type ContextMenuOpts = ContextMenuOption;
    namespace Context {
        /**
         * Table identifiers for built-in Zowe Explorer tables
         */
        enum Identifiers {
            DATA_SETS = "data-sets",
            DATA_SET_MEMBERS = "data-set-members",
            JOBS = "jobs",
            SEARCH_RESULTS = "search-results"
        }
        /**
         * Base interface for table context information passed to action providers
         */
        interface IBaseData {
            /** The type of table being displayed */
            tableId: string;
            /** Additional properties specific to the table implementation */
            [key: string]: any;
        }
        /**
         * Context information for data set-related tables
         */
        interface DataSet extends IBaseData {
            /** The current table type (data sets or members) */
            tableType: "dataSets" | "members" | null;
            /** The data source being used by the table */
            dataSource: IDataSetSource;
            /** Profile information if available */
            profile?: imperative.IProfileLoaded;
            /** Profile name if available */
            profileName?: string;
            /** Tree node if the table is derived from a tree node */
            treeNode?: IZoweTreeNode;
        }
        /**
         * Context information for job-related tables
         */
        interface Job extends IBaseData {
            /** Profile information if available */
            profile?: imperative.IProfileLoaded;
            /** Profile name if available */
            profileName?: string;
            /** Tree node if the table is derived from a tree node */
            treeNode?: IZoweTreeNode;
        }
        /**
         * Context information for search result tables
         */
        interface Search extends IBaseData {
            /** The search query that generated these results */
            searchQuery?: string;
            /** The type of search performed */
            searchType?: "data-set" | "member";
            /** Profile information if available */
            profile?: imperative.IProfileLoaded;
            /** Profile name if available */
            profileName?: string;
        }
        /**
         * Type guard to check if context is a Dataset context
         */
        function isDataSet(context: IBaseData | undefined): context is DataSet;
        /**
         * Type guard to check if context is a Job context
         */
        function isJob(context: IBaseData | undefined): context is Job;
        /**
         * Type guard to check if context is a Search context
         */
        function isSearch(context: IBaseData | undefined): context is Search;
        /**
         * Utility function to safely get dataset context with type checking
         */
        function getDataset(context: IBaseData | undefined): DataSet | undefined;
        /**
         * Utility function to safely get job context with type checking
         */
        function getJob(context: IBaseData | undefined): Job | undefined;
        /**
         * Utility function to safely get search context with type checking
         */
        function getSearch(context: IBaseData | undefined): Search | undefined;
    }
    /** Value formatter callback. Expects the exact display value to be returned. */
    type ValueFormatter = (data: {
        value: ContentTypes;
    }) => string;
    type Positions = "left" | "right";
    /**
     * Returns a date comparison function for sorting date columns.
     * @returns A function that compares two date values
     */
    function getDateComparator(): (valueA: any, valueB: any, nodeA: any, nodeB: any, isDescending: boolean) => number;
    /** The column type definition. All available properties are offered for AG Grid columns. */
    type Column = {
        field: string;
        type?: string | string[];
        cellDataType?: boolean | string;
        valueFormatter?: string;
        checkboxSelection?: boolean;
        icons?: {
            [key: string]: string;
        };
        suppressNavigable?: boolean;
        context?: any;
        hide?: boolean;
        initialHide?: boolean;
        lockVisible?: boolean;
        lockPosition?: boolean | Positions;
        suppressMovable?: boolean;
        editable?: boolean;
        singleClickEdit?: boolean;
        filter?: boolean;
        floatingFilter?: boolean;
        headerName?: string;
        headerTooltip?: string;
        headerClass?: string | string[];
        wrapHeaderText?: boolean;
        autoHeaderHeight?: boolean;
        headerCheckboxSelection?: boolean;
        pinned?: boolean | Positions | null;
        initialPinned?: boolean | Positions;
        lockPinned?: boolean;
        rowDrag?: boolean;
        dndSource?: boolean;
        sortable?: boolean;
        sort?: "asc" | "desc";
        initialSort?: "asc" | "desc";
        sortIndex?: number | null;
        initialSortIndex?: number;
        sortingOrder?: ("asc" | "desc")[];
        comparator?: string;
        unSortIcon?: boolean;
        useDateComparison?: boolean;
        colSpan?: string;
        rowSpan?: string;
        width?: number;
        initialWidth?: number;
        minWidth?: number;
        maxWidth?: number;
        flex?: number;
        initialFlex?: number;
        resizable?: boolean;
        suppressSizeToFit?: boolean;
        suppressAutoSize?: boolean;
    };
    type ColumnOpts = Omit<Column, "comparator" | "colSpan" | "rowSpan" | "valueFormatter"> & {
        comparator?: (valueA: any, valueB: any, nodeA: any, nodeB: any, isDescending: boolean) => number;
        colSpan?: (params: any) => number;
        rowSpan?: (params: any) => number;
        valueFormatter?: ValueFormatter;
        useDateComparison?: boolean;
    };
    interface SizeColumnsToFitGridStrategy {
        type: "fitGridWidth";
        defaultMinWidth?: number;
        defaultMaxWidth?: number;
        columnLimits?: SizeColumnsToFitGridColumnLimits[];
    }
    interface SizeColumnsToFitGridColumnLimits {
        colId: string;
        minWidth?: number;
        maxWidth?: number;
    }
    interface SizeColumnsToFitProvidedWidthStrategy {
        type: "fitProvidedWidth";
        width: number;
    }
    interface SizeColumnsToContentStrategy {
        type: "fitCellContents";
        skipHeader?: boolean;
        colIds?: string[];
    }
    type GridProperties = {
        /** Allow reordering and pinning columns by dragging columns from the Columns Tool Panel to the grid */
        allowDragFromColumnsToolPanel?: boolean;
        /** Number of pixels to add a column width after the auto-sizing calculation */
        autoSizePadding?: number;
        /**
         * Auto-size the columns when the grid is loaded. Can size to fit the grid width, fit a provided width or fit the cell contents.
         * Read once during initialization.
         */
        autoSizeStrategy?: SizeColumnsToFitGridStrategy | SizeColumnsToFitProvidedWidthStrategy | SizeColumnsToContentStrategy;
        /** Set to 'shift' to have shift-resize as the default resize operation */
        colResizeDefault?: "shift";
        /** Changes the display type of the column menu. 'new' displays the main list of menu items; 'legacy' displays a tabbed menu */
        columnMenu?: "legacy" | "new";
        /** Set this to `true` to enable debugging information from the grid */
        debug?: boolean;
        /** Set this to `true` to allow checkbox selection, no matter what row is visible. */
        selectEverything?: boolean;
        /** Set this to suppress row-click selection, in favor of checkbox selection. */
        suppressRowClickSelection?: boolean;
        /** The height in pixels for the rows containing floating filters. */
        floatingFiltersHeight?: number;
        /** The height in pixels for the rows containing header column groups. */
        groupHeaderHeight?: number;
        /** The height in pixels for the row contianing the column label header. Default provided by the AG Grid theme. */
        headerHeight?: number;
        /** Show/hide the "Loading" overlay */
        loading?: boolean;
        /** Map of key:value pairs for localizing grid text. Read once during initialization. */
        localeText?: {
            [key: string]: string;
        };
        /** Keeps the order of columns maintained after new Column Definitions are updated. */
        maintainColumnOrder?: boolean;
        /** Whether the table should be split into pages. */
        pagination?: boolean;
        /**
         * Set to `true` so that the number of rows to load per page is automatically adjusted by the grid.
         * If `false`, `paginationPageSize` is used.
         */
        paginationAutoPageSize?: boolean;
        /** How many rows to load per page */
        paginationPageSize?: number;
        /**
         * Set to an array of values to show the page size selector with custom list of possible page sizes.
         * Set to `true` to show the page size selector with the default page sizes `[20, 50, 100]`.
         * Set to `false` to hide the page size selector.
         */
        paginationPageSizeSelector?: number[] | boolean;
        /** If defined, rows are filtered using this text as a Quick Filter. */
        quickFilterText?: string;
        /** Enable selection of rows in table */
        rowSelection?: "single" | "multiple";
        /** Set to `true` to skip the `headerName` when `autoSize` is called by default. Read once during initialization. */
        skipHeaderOnAutoSize?: boolean;
        /**
         * Suppresses auto-sizing columns for columns - when enabled, double-clicking a column's header's edge will not auto-size.
         * Read once during initialization.
         */
        suppressAutoSize?: boolean;
        suppressColumnMoveAnimation?: boolean;
        /** If `true`, when you dreag a column out of the grid, the column is not hidden */
        suppressDragLeaveHidesColumns?: boolean;
        /** If `true`, then dots in field names are not treated as deep references, allowing you to use dots in your field name if preferred. */
        suppressFieldDotNotation?: boolean;
        /**
         * When `true`, the column menu button will always be shown.
         * When `false`, the column menu button will only show when the mouse is over the column header.
         * If `columnMenu = 'legacy'`, this will default to `false` instead of `true`.
         */
        suppressMenuHide?: boolean;
        /** Set to `true` to suppress column moving (fixed position for columns) */
        suppressMovableColumns?: boolean;
        /** Enables custom tree mode support (custom cell renderer). */
        customTreeMode?: boolean;
        /** The 'field' of the column to be used for displaying the tree hierarchy in custom tree mode. */
        customTreeColumnField?: string;
        /** Initial depth of expansion for custom tree mode. 0 for all collapsed (default), -1 for all expanded. */
        customTreeInitialExpansionDepth?: number;
    };
    type ViewOpts = {
        /** Actions to apply to the given row or column index */
        actions: Record<number | "all", Action[]>;
        /** Column definitions for the top of the table */
        columns: Column[];
        /** Context menu options for rows in the table */
        contextOpts: Record<number | "all", ContextMenuOption[]>;
        /** The row data for the table. Each row contains a set of variables corresponding to the data for each column in that row. */
        rows: RowData[];
        /** The display title for the table */
        title?: string;
        /** AG Grid-specific properties */
        options?: GridProperties;
    };
    type EditEvent = {
        rowIndex: number;
        field: string;
        value: ContentTypes;
        oldValue?: ContentTypes;
    };
    /**
     * A class that acts as a controller between the extension and the table view. Based off of the {@link WebView} class.
     *
     * @remarks
     * ## Usage
     *
     * To easily configure a table before creating a table view,
     * use the `TableBuilder` class to prepare table data and build an instance.
     */
    class View extends WebView {
        private lastUpdated;
        private data;
        private onDidReceiveMessageEmitter;
        private onTableDataReceivedEmitter;
        private onTableDisplayChangedEmitter;
        private onTableDataEditedEmitter;
        onDidReceiveMessage: Event<object>;
        onTableDisplayChanged: Event<RowData | RowData[]>;
        onTableDataReceived: Event<Partial<ViewOpts>>;
        onTableDataEdited: Event<EditEvent>;
        private pendingRequests;
        private uuid;
        private apiReady;
        private apiReadyResolvers;
        getUris(): UriPair;
        getHtml(): string;
        constructor(context: ExtensionContext, isView?: boolean, data?: ViewOpts);
        private evaluateCondition;
        private getConditionData;
        /**
         * (Receiver) message handler for the table view.
         * Used to dispatch client-side updates of the table to subscribers when the table's display has changed.
         *
         * @param message The message received from the webview
         */
        onMessageReceived(message: any): Promise<void>;
        /**
         * (Sender) message handler for the table view.
         * Used to send data and table layout changes to the table view to be re-rendered.
         *
         * @returns Whether the webview received the update that was sent
         */
        private updateWebview;
        /**
         * Access the unique ID for the table view instance.
         *
         * @returns The unique ID for this table view
         */
        getId(): string;
        /**
         * Add one or more actions to the given row.
         *
         * @param index The row index where the action should be displayed
         * @param actions The actions to add to the given row
         *
         * @returns Whether the webview successfully received the new action(s)
         */
        addAction(index: number | "all", ...actions: Action[]): Promise<boolean>;
        /**
         * Add one or more context menu options to the given row.
         *
         * @param id The row index or column ID where the action should be displayed
         * @param options The context menu options to add to the given row
         * @returns Whether the webview successfully received the new context menu option(s)
         */
        addContextOption(id: number | "all", ...options: ContextMenuOption[]): Promise<boolean>;
        /**
         * Get rows of content from the table view.
         * @param rows The rows of data in the table
         * @returns Whether the webview successfully received the new content
         */
        getContent(): RowData[];
        getPageSize(): Promise<number>;
        setPageSize(pageSize: number): Promise<boolean>;
        getGridState(): Promise<any>;
        setGridState(state: any): Promise<boolean>;
        setPage(page: number): Promise<boolean>;
        getPage(): Promise<number>;
        /**
         * Add rows of content to the table view.
         * @param rows The rows of data to add to the table
         * @returns Whether the webview successfully received the new content
         */
        addContent(...rows: RowData[]): Promise<boolean>;
        /**
         * Update an existing row in the table view.
         * @param index The AG GRID row index to update within the table
         * @param row The new row content. If `null`, the given row index will be deleted from the list of rows.
         * @returns Whether the webview successfully updated the new row
         */
        updateRow(index: number, row: RowData | null): Promise<boolean>;
        /**
         * Adds headers to the end of the existing header list in the table view.
         *
         * @param headers The headers to add to the existing header list
         * @returns Whether the webview successfully received the list of headers
         */
        addColumns(...columns: ColumnOpts[]): Promise<boolean>;
        /**
         * Sets the content for the table; replaces any pre-existing content.
         *
         * @param rows The rows of data to apply to the table
         * @returns Whether the webview successfully received the new content
         */
        setContent(rows: RowData[]): Promise<boolean>;
        /**
         * Sets the headers for the table.
         *
         * @param headers The new headers to use for the table
         * @returns Whether the webview successfully received the new headers
         */
        setColumns(columns: ColumnOpts[]): Promise<boolean>;
        /**
         * Sets the options for the table.
         *
         * @param opts The optional grid properties for the table
         * @returns Whether the webview successfully received the new options
         */
        setOptions(opts: GridProperties): Promise<boolean>;
        /**
         * Sets the display title for the table view.
         *
         * @param title The new title for the table
         * @returns Whether the webview successfully received the new title
         */
        setTitle(title: string): Promise<boolean>;
        /**
         * Request data from the webview and return the response.
         * Similar to the MessageHandler.request method but for table views.
         *
         * @param command The command to send to the webview
         * @param payload Optional payload to send with the request
         * @returns A promise that resolves with the response from the webview
         */
        request<T>(command: string, payload?: any): Promise<T>;
        /**
         * Wait for the AG Grid API to be ready.
         * This method resolves when the grid has been initialized and the API is available for use.
         *
         * @returns A promise that resolves when the AG Grid API is ready
         */
        waitForAPI(): Promise<void>;
        /**
         * Pin the specified rows to the top of the grid.
         * @param rows The rows to pin to the top
         * @returns Whether the webview successfully pinned the rows
         */
        pinRows(rows: RowData[]): Promise<boolean>;
        /**
         * Unpin the specified rows from the top of the grid.
         * @param rows The rows to unpin
         * @returns Whether the webview successfully unpinned the rows
         */
        unpinRows(rows: RowData[]): Promise<boolean>;
        /**
         * Get all currently pinned rows from the top of the grid.
         * @returns Array of pinned row data
         */
        getPinnedRows(): Promise<RowData[]>;
        /**
         * Set the pinned rows to a specific array of rows.
         *
         * This method replaces all currently pinned rows with the provided array.
         * Unlike pinRows() which adds to existing pinned rows, this method completely
         * replaces the pinned row data.
         *
         * @param rows The rows to set as pinned (empty array clears all pinned rows)
         * @returns Whether the webview successfully set the pinned rows
         *
         * @example
         * // Clear all pinned rows
         * await tableView.setPinnedRows([]);
         *
         * // Set specific rows as pinned (replaces any existing pinned rows)
         * await tableView.setPinnedRows([row1, row2, row3]);
         */
        setPinnedRows(rows: RowData[]): Promise<boolean>;
    }
    class Instance extends View {
        constructor(context: ExtensionContext, isView: boolean, data: Table.ViewOpts);
        /**
         * Closes the table view and marks it as disposed.
         * Removes the table instance from the mediator if it exists.
         */
        dispose(): void;
    }
}
