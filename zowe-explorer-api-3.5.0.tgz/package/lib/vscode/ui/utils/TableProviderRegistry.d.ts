/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import type { Table } from "../TableView";
/**
 * Interface for table action providers that extenders can implement
 * to contribute actions and context menu items to tables
 */
export interface TableActionProvider {
    /**
     * Provide actions for a table based on its context
     * @param context The table context information
     * @returns Array of actions to add to the table
     */
    provideActions(context: Table.Context.IBaseData): Table.Action[] | Promise<Table.Action[]>;
    /**
     * Provide context menu items for a table based on its context
     * @param context The table context information
     * @returns Array of context menu items to add to the table
     */
    provideContextMenuItems?(context: Table.Context.IBaseData): Table.ContextMenuOption[] | Promise<Table.ContextMenuOption[]>;
}
/**
 * Registry for managing table action providers and table identifiers
 * Provides extensibility for table views by allowing extenders to register providers
 * that can contribute actions and context menu items
 */
export declare class TableProviderRegistry {
    private static instance;
    private providers;
    private constructor();
    /**
     * Get the singleton instance of the registry
     */
    static getInstance(): TableProviderRegistry;
    /**
     * Register a table action provider for a specific table ID
     * @param tableId The table identifier to register the provider for
     * @param provider The action provider implementation
     */
    registerProvider(tableId: string, provider: TableActionProvider): void;
    /**
     * Unregister a table action provider for a specific table ID
     * @param tableId The table identifier to unregister the provider from
     * @param provider The action provider to remove
     */
    unregisterProvider(tableId: string, provider: TableActionProvider): void;
    /**
     * Get all actions from registered providers for a table
     * @param context The table context information
     * @returns Array of actions from all providers
     */
    getActions(context: Table.Context.IBaseData): Promise<Table.Action[]>;
    /**
     * Get all context menu items from registered providers for a table
     * @param context The table context information
     * @returns Array of context menu items from all providers
     */
    getContextMenuItems(context: Table.Context.IBaseData): Promise<Table.ContextMenuOption[]>;
    /**
     * Get all registered table IDs
     * @returns Array of table IDs that have registered providers
     */
    getRegisteredTableIds(): string[];
}
