/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { ExtensionContext } from "vscode";
import { Table } from "../TableView";
/**
 * A builder class for quickly instantiating {@link Table.View} instances.
 * Especially useful for building multiple tables with similar layouts or data.
 *
 * @remarks
 *
 * ## Building a table
 *
 * Developers can build a table using the helper methods provided by the builder.
 * Once a table is ready to be built, use the {@link TableBuilder.build} function to create
 * a new {@link Table.View} instance with the given configuration.
 *
 * ## Sharing tables
 *
 * Share a table during the build process by using the {@link TableBuilder.buildAndShare} function.
 * This function will create the {@link Table.View} instance while also adding it to the mediator
 * in Zowe Explorer's extender API. Extenders who would like to contribute to shared tables can do
 * so by accessing the table by its unique ID.
 */
export declare class TableBuilder {
    private context;
    private data;
    private forWebviewView;
    constructor(context: ExtensionContext);
    /**
     * Prepares the table to be rendered within a WebviewViewProvider (such as the "Zowe Resources" panel)
     * @returns The instance of the TableBuilder, with the private `forWebviewView` flag set to `true`
     */
    isView(): this;
    /**
     * Set optional properties for the table view.
     * @param opts The options for the table
     * @returns The same {@link TableBuilder} instance with the options added
     */
    options(opts: Table.GridProperties): this;
    /**
     * Set the title for the next table.
     * @param name The name of the table
     * @returns The same {@link TableBuilder} instance with the title added
     */
    title(name: string): this;
    /**
     * Set the rows for the next table.
     * @param rows The rows of content to use for the table
     * @returns The same {@link TableBuilder} instance with the rows added
     */
    rows(...rows: Table.RowData[]): this;
    /**
     * Adds rows to the table. Does not replace existing rows.
     * @param rows The rows of content to add to the table
     * @returns The same {@link TableBuilder} instance with the new rows added
     */
    addRows(rows: Table.RowData[]): this;
    /**
     * Set the columns for the next table.
     * @param columns The columns to use for the table
     * @returns The same {@link TableBuilder} instance with the columns added
     */
    columns(...columns: Table.ColumnOpts[]): this;
    private convertColumnOpts;
    /**
     * Adds columns to the table. Does not replace existing columns.
     * @param columns The column definitions to add to the table
     * @returns The same {@link TableBuilder} instance with the new column definitions added
     */
    addColumns(columns: Table.ColumnOpts[]): this;
    /**
     * Add context options for the next table.
     * @param actions the record of indices to {@link Table.Action} arrays to use for the table
     * @returns The same {@link TableBuilder} instance with the row actions added
     */
    contextOptions(opts: Record<number | "all", Table.ContextMenuOption[]>): this;
    /**
     * Add a context menu option to the table.
     * @param index The row index to add an option to (or "all" for all rows)
     * @returns The same {@link TableBuilder} instance with the context menu option added
     */
    addContextOption(index: number | "all", option: Table.ContextMenuOption): this;
    /**
     * Add row actions for the next table.
     * @param actions the record of indices to {@link Table.Action} arrays to use for the table
     * @returns The same {@link TableBuilder} instance with the row actions added
     */
    rowActions(actions: Record<number | "all", Table.Action[]>): this;
    /**
     * Add a row action to the next table.
     * @param index The column index to add an action to
     * @returns The same {@link TableBuilder} instance with the row action added
     */
    addRowAction(index: number | "all", action: Table.Action): this;
    /**
     * Builds the table with the given data.
     * @returns A new {@link Table.Instance} with the given data/options
     */
    build(): Table.Instance;
    /**
     * Builds the table with the given data and shares it with the TableMediator singleton.
     * @returns A new, **shared** {@link Table.Instance} with the given data/options
     */
    buildAndShare(): Table.Instance;
    /**
     * Resets all data configured in the builder from previously-created table views.
     */
    reset(): void;
}
