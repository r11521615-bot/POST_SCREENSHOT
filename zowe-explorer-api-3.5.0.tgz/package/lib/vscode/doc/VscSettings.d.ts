/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import * as imperative from "@zowe/imperative";
export declare class VscSettings {
    /**
     * Retrieves a generic setting either in user or workspace.
     * @param {string} key - The config property that needs retrieving
     * @param {T} defaultValue - Default value if config property is undefined
     */
    static getDirectValue<T>(key: string, defaultValue?: T): T;
    static getVsCodeProxySettings(): imperative.ProxyVariables;
}
