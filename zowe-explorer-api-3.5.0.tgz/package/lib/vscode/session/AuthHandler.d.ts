/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { CorrelatedError } from "../../utils";
import * as imperative from "@zowe/imperative";
import { IZoweTreeNode } from "../../tree";
import { Mutex } from "async-mutex";
import * as vscode from "vscode";
/**
 * @brief individual authentication methods (also supports a `ProfilesCache` class)
 */
export interface IAuthMethods {
    ssoLogin: (node?: IZoweTreeNode, profileName?: string) => PromiseLike<boolean>;
    promptCredentials: (profile: string | imperative.IProfileLoaded, rePrompt?: boolean) => PromiseLike<string[]>;
}
export type AuthPromptParams = {
    isUsingTokenAuth?: boolean;
    errorCorrelation?: CorrelatedError;
    authMethods: IAuthMethods;
    imperativeError: imperative.ImperativeError;
    throwErrorOnCancel?: boolean;
};
export type ProfileLike = string | imperative.IProfileLoaded;
/**
 * Error thrown when the user cancels an authentication prompt.
 * This allows extenders to distinguish between authentication failures and user cancellation.
 * Extends FileSystemError to be compliant with VS Code's filesystem API expectations.
 */
export declare class AuthCancelledError extends vscode.FileSystemError {
    readonly profileName: string;
    constructor(profileName: string, message?: string);
}
export declare class AuthHandler {
    static authPromptLocks: Map<string, Mutex>;
    private static profileLocks;
    private static authCancelledProfiles;
    private static authFlows;
    private static sequentialLocks;
    private static parallelEnabledProfiles;
    private static enabledProfileTypes;
    /**
     * Records whether the user cancelled the authentication prompt for a profile.
     * @param profile The profile to update
     * @param wasCancelled Whether the prompt was cancelled
     */
    static setAuthCancelled(profile: ProfileLike, wasCancelled: boolean): void;
    /**
     * Checks if the last authentication attempt for a profile was cancelled.
     * @param profile The profile to check
     * @returns {boolean} True if authentication was cancelled, false otherwise
     */
    static wasAuthCancelled(profile: ProfileLike): boolean;
    /**
     * Enables profile locks for the given type.
     * @param type The profile type to enable locks for.
     */
    static enableLocksForType(type: string): void;
    /**
     * Disables profile locks for the given type.
     * @param type The profile type to disable locks for.
     */
    static disableLocksForType(type: string): void;
    /**
     * Function that returns the session associated with the specified profile.
     *
     * @param {imperative.IProfileLoaded} profile The profile to be inspected.
     *
     * @returns {imperative.Session}
     *      The session associated with the specified profile
     *
     * @throws {Error} If the profile type is not supported by the common APIs in the Zowe Explorer API register
     */
    static getSessFromProfile(profile: imperative.IProfileLoaded): imperative.Session;
    /**
     * Function that returns the session type for the specified session.
     *
     * @param {imperative.Session} session The session to be inspected.
     *
     * @returns {imperative.SessConstants.AUTH_TYPE_CHOICES}
     *      The session type for the specified session
     */
    static sessTypeFromSession(session: imperative.Session): imperative.SessConstants.AUTH_TYPE_CHOICES;
    /**
     * Function that returns the session type for the session associated with the specified profile.
     *
     * @param {imperative.IProfileLoaded} profile The profile to be inspected.
     *
     * @returns {imperative.SessConstants.AUTH_TYPE_CHOICES}
     *      The session type for the session associated with the specified profile
     *
     * @throws {Error} If the profile type is not supported by the common APIs in the Zowe Explorer API register
     */
    static sessTypeFromProfile(profile: imperative.IProfileLoaded): imperative.SessConstants.AUTH_TYPE_CHOICES;
    /**
     * Function that checks whether a profile is using token based authentication
     * @deprecated Use AuthHandler.sessTypeFromProfile and/or AuthHandler.sessTypeFromSession, which will adhere to authOrder.
     * @param {string[]} profileProps Secure properties for the service profile
     * @param {string[]} baseProfileProps Base profile's secure properties (optional)
     * @returns {Promise<boolean>} a boolean representing whether token based auth is being used or not
     */
    static isUsingTokenAuth(profileProps: string[], baseProfileProps?: string[]): boolean;
    /**
     * Unlocks the given profile so it can be used again.
     * @param profile {ProfileLike} The profile (name or {@link imperative.IProfileLoaded} object) to unlock
     * @param refreshResources {boolean} Whether to refresh high-priority resources (active editor & virtual workspace) after unlocking
     */
    static unlockProfile(profile: ProfileLike, refreshResources?: boolean): void;
    /**
     * Prompts the user to authenticate over SSO or a credential prompt in the event of an error.
     * @param profile The profile to authenticate
     * @param params {AuthPromptParams} Prompt parameters (login methods, using token auth, error correlation)
     * @returns {boolean} Whether authentication was successful
     * @throws {AuthCancelledError} When the user cancels the authentication prompt
     */
    static promptForAuthentication(profile: ProfileLike, params: AuthPromptParams): Promise<boolean>;
    /**
     * Locks the given profile to prevent further use in asynchronous operations (at least where the lock is respected).
     * Supports prompting for authentication if an Imperative error and prompt options are given.
     * @param profile The profile to lock
     * @param authOpts Authentication methods and related options. If provided, {@link promptForAuthentication} will be called with the given options.
     * @returns Whether the profile was successfully locked
     */
    static lockProfile(profile: ProfileLike, authOpts?: AuthPromptParams): Promise<boolean>;
    /**
     * Ensures follow-up requests for a profile execute sequentially by removing any parallel override.
     * Creates a mutex for the profile if one does not yet exist.
     * @param profile Profile name or object that should run requests sequentially
     */
    static enableSequentialRequests(profile: ProfileLike): void;
    /**
     * Allows a profile's requests to execute in parallel and discards its sequential mutex when idle.
     * @param profile Profile name or object that should run requests concurrently
     */
    static disableSequentialRequests(profile: ProfileLike): void;
    /**
     * Checks whether sequential request execution is currently enforced for a profile.
     * @param profile Profile name or object to check
     * @returns `true` when the profile is locked to sequential requests, `false` if parallel requests are allowed
     */
    static areSequentialRequestsEnabled(profile: ProfileLike): boolean;
    /**
     * Runs the given action under the profile's sequential mutex when sequential mode is enabled.
     * Falls back to invoking the action immediately if parallel mode is active.
     * @param profile Profile name or object that dictates whether sequential mode applies
     * @param action Async function to run sequentially
     * @returns Resolves with the action's result
     */
    static runSequentialIfEnabled<T>(profile: ProfileLike, action: () => Promise<T>): Promise<T>;
    private static isProfileLoaded;
    private static getProfileName;
    /**
     * Waits for the profile to be unlocked (ONLY if the profile was locked after an authentication error)
     * @param profile The profile name or object that may be locked
     */
    static waitForUnlock(profile: ProfileLike): Promise<void>;
    /**
     * Releases locks for all profiles.
     * Used for scenarios such as the `onVaultChanged` event, where we don't know what secure values have changed,
     * but we can't assume that the profile still has invalid credentials.
     */
    static unlockAllProfiles(): void;
    /**
     * Checks whether the given profile has its lock acquired.
     * @param profile The profile to check
     * @returns {boolean} `true` if the given profile is locked, `false` otherwise
     */
    static isProfileLocked(profile: ProfileLike): boolean;
    static getActiveAuthFlow(profile: ProfileLike): Promise<void> | undefined;
    static getOrCreateAuthFlow(profile: ProfileLike, authOpts: AuthPromptParams): Promise<void>;
    private static releaseMutexIfLocked;
}
