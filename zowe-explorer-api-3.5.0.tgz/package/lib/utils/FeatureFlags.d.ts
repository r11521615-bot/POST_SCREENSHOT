/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
export interface FlagSchema {
    [key: string]: boolean | string | number | any;
}
export declare enum FlagAccessLevel {
    None = 0,
    Read = 1,
    Write = 2
}
export type FeatureFlagKey = string;
export declare class FeatureFlags {
    private static filePath;
    private static flags;
    private static isInitialized;
    protected constructor();
    /**
     * Initializes the manager by loading existing flags from disk.
     * Must be called before using get/set if persistence is required immediately.
     */
    static init(): Promise<void>;
    /**
     * Reloads the flags from the JSON file into memory.
     * Useful if the file is modified by an external process.
     */
    static reload(): Promise<void>;
    /**
     * Gets the value of a specific feature flag.
     * Returns from in-memory cache
     */
    static get(key: string): any;
    /**
     * Sets a flag value and persists it to the JSON file if requested.
     * Updates the in-memory cache immediately.
     * @param key - The feature flag key identifier.
     * @param value - The value to assign to the flag.
     * @param save - Whether to persist the change to disk immediately (default: `false`).
     * If `false`, the operation only updates memory and does not need to be awaited.
     * @returns A promise that resolves when the operation is complete.
     */
    static set(key: string, value: any, save?: boolean): Promise<void>;
    /**
     * Deletes a flag and persists the change.
     */
    static remove(key: string): void;
    private static loadFromDisk;
    private static saveToDisk;
}
export declare class FeatureFlagsAccess extends FeatureFlags {
    private static accessControl;
    /**
     * Asserts that the given key is readable.
     * @param key The feature flag key to read
     * @throws If the key is not readable from the access facility
     */
    private static expectReadable;
    /**
     * Asserts that the given key is writable.
     * @param key The feature flag key to write
     * @throws If the key is not writable from the access facility
     */
    private static expectWritable;
    /**
     * @returns The list of readable keys from the access facility
     */
    static getReadableKeys(): FeatureFlagKey[];
    /**
     * @returns The list of writable keys from the access facility
     */
    static getWritableKeys(): FeatureFlagKey[];
    /**
     * Gets the value of a specific feature flag with ACL check.
     * @param key The feature flag key
     * @returns The value of the flag
     * @throws If the extender does not have appropriate read permissions
     */
    static get(key: FeatureFlagKey): any;
    /**
     * Sets a flag value with ACL check and persists it to the JSON file.
     * @param key The feature flag key
     * @param value The value to set
     * @param save Whether to persist to disk immediately
     * @throws If the extender does not have appropriate write permissions
     */
    static set(key: FeatureFlagKey, value: any, save?: boolean): Promise<void>;
}
