/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
export declare class FileManagement {
    static permStringToOctal(perms: string): number;
    static getZoweDir(): string;
    static getFullPath(anyPath: string): string;
    static reloadActiveEditorForProfile(profileName: string): Promise<void>;
    static reloadWorkspacesForProfile(profileName: string): Promise<void>;
}
