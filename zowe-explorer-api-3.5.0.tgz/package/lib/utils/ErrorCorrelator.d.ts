/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
/**
 * Error match type (substring of error, or regular expression to match against error text)
 */
type ErrorMatch = string | RegExp;
export interface ExternalResource {
    href: string;
    title?: string;
}
export interface ErrorCorrelation {
    /**
     * An optional error code returned from the server.
     * @type {string}
     */
    errorCode?: string;
    /**
     * One or more patterns to check for within the error message.
     * @type {ErrorMatch | ErrorMatch[]}
     */
    matches: ErrorMatch | ErrorMatch[];
    /**
     * Human-readable, brief summary of the error that was encountered.
     * @type {string}
     */
    summary: string;
    /**
     * Troubleshooting tips for end users that encounter the given error.
     * @type {string[]}
     */
    tips?: string[];
    /**
     * Error-specific, external resources for users to help with resolution during troubleshooting.
     */
    resources?: ExternalResource[];
}
export interface CorrelatedErrorProps {
    errorCode?: string;
    correlation?: Omit<ErrorCorrelation, "matches">;
    initialError: Error | string;
}
export interface CorrelateErrorOpts {
    profileType?: string;
    templateArgs?: Record<string, string>;
}
export interface DisplayErrorOpts extends CorrelateErrorOpts {
    additionalContext?: string;
    allowRetry?: boolean;
}
export interface DisplayCorrelatedErrorOpts extends Omit<DisplayErrorOpts, "profileType"> {
}
export interface HandledErrorInfo {
    correlation: CorrelatedError;
    userResponse: string | undefined;
}
/**
 * Representation of the given error as a correlated error (wrapper around the `Error` class).
 *
 * Used to cache the error info such as tips, the match that was encountered and the full error message.
 */
export declare class CorrelatedError {
    properties: CorrelatedErrorProps;
    errorCode?: string;
    message: string;
    private wasCorrelated;
    constructor(properties: CorrelatedErrorProps);
    get correlationFound(): boolean;
    get stack(): string | undefined;
    get initial(): Error | string;
    asError(): Error;
    toString(): string;
}
export declare enum ZoweExplorerApiType {
    Mvs = "mvs",
    Jes = "jes",
    Uss = "uss",
    Command = "cmd",
    All = "all"
}
export type ErrorsForApiType = Map<ZoweExplorerApiType, ApiErrors>;
export type ApiErrors = Record<string, ErrorCorrelation[]>;
export declare class ErrorCorrelator {
    private static instance;
    private errorMatches;
    private constructor();
    static getInstance(): ErrorCorrelator;
    /**
     * Adds a new error correlation to the map of error matches.
     *
     * @param api The API type that corresponds with the error
     * @param profileType A profile type that the error occurs within
     * @param correlation The correlation info (summary, tips, etc.)
     */
    addCorrelation(api: ZoweExplorerApiType, profileType: string, correlation: ErrorCorrelation): void;
    /**
     * Attempt to correlate the error details to an error contributed to the `errorMatches` map.
     *
     * @param api The API type where the error was encountered
     * @param profileType The profile type in use
     * @param errorDetails The full error details (usually `error.message`)
     * @returns A matching `CorrelatedError`, or a generic `CorrelatedError` with the full error details as the summary
     */
    correlateError(api: ZoweExplorerApiType, error: string | Error, opts?: CorrelateErrorOpts): CorrelatedError;
    /**
     * Translates a detailed error message to a user-friendly summary.
     * Full error details are available through the "More info" dialog option.
     *
     * @param api The API type where the error was encountered
     * @param profileType The profile type in use
     * @param errorDetails The full error details (usually `error.message`)
     * @param allowRetry Whether to allow retrying the action
     * @returns The user selection ("Retry" [if enabled] or "Troubleshoot")
     */
    displayCorrelatedError(error: CorrelatedError, opts?: DisplayCorrelatedErrorOpts): Promise<string | undefined>;
    /**
     * Translates a detailed error message to a user-friendly summary.
     * Full error details are available through the "More info" dialog option.
     *
     * @param api The API type where the error was encountered
     * @param profileType The profile type in use
     * @param errorDetails The full error details (usually `error.message`)
     * @param allowRetry Whether to allow retrying the action
     * @returns The user selection ("Retry" [if enabled] or "Troubleshoot")
     */
    displayError(api: ZoweExplorerApiType, errorDetails: string | Error, opts?: DisplayErrorOpts): Promise<HandledErrorInfo>;
}
export {};
