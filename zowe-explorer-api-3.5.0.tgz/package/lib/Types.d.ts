/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { FileDecoration, Uri } from "vscode";
import { ICreateDataSetOptions } from "@zowe/zos-files-for-zowe-sdk";
import type { IApiExplorerExtender, IRegisterClient } from "./extend";
import type { IZoweDatasetTreeNode, IZoweJobTreeNode, IZoweTreeNode, IZoweUSSTreeNode, IZoweTree } from "./tree";
export declare namespace Types {
    type IZoweNodeType = IZoweDatasetTreeNode | IZoweUSSTreeNode | IZoweJobTreeNode;
    type IZoweDatasetTreeType = IZoweTree<IZoweDatasetTreeNode>;
    type IZoweUSSTreeType = IZoweTree<IZoweUSSTreeNode>;
    type IZoweJobTreeType = IZoweTree<IZoweJobTreeNode>;
    type ZoweNodeInteraction = {
        node?: IZoweTreeNode;
        date?: Date;
    };
    type IApiRegisterClient = IRegisterClient & {
        /**
         * Lookup of an API for the generic extender API.
         * @returns the registered API instance
         */
        getExplorerExtenderApi(): IApiExplorerExtender;
    };
    type WebviewUris = {
        build: Uri;
        script: Uri;
        css?: Uri;
        codicons?: Uri;
    };
    type FileAttributes = {
        gid: number;
        group: string;
        owner: string;
        uid: number;
        perms: string;
        tag?: string;
    };
    type PollRequest = {
        msInterval: number;
        dispose?: boolean;
        decoration?: FileDecoration;
        reject?<T = never>(reason?: any): Promise<T>;
        resolve?: (uniqueId: string, data: any) => any;
        request: () => unknown | Promise<unknown>;
        [key: string]: any;
    };
    type DatasetStats = {
        user: string;
        createdDate: Date;
        modifiedDate: Date;
        [key: string]: any;
    };
    type KeytarModule = {
        deletePassword: (service: string, account: string) => Promise<boolean>;
        findPassword: (service: string, account: string) => Promise<string | null>;
        findCredentials: (name: string) => Promise<{
            account: string;
            password: string;
        }[]>;
        getPassword: (service: string, account: string) => Promise<string | null>;
        setPassword: (service: string, account: string, password: string) => Promise<void>;
    };
    /**
     * @type DataSetAllocTemplate
     * Used during creation of data sets in Zowe Explorer to access and manipulate a list of saved templates
     * presented to or saved by the user
     */
    type DataSetAllocTemplate = {
        [key: string]: ICreateDataSetOptions;
    };
    type Appender = {
        type: string;
        layout: {
            type: string;
            pattern: string;
        };
        filename: string;
    };
    type Log4JsCfg = {
        log4jsConfig: {
            appenders: {
                [key: string]: Appender;
            };
        };
    };
    type AddSessionOpts = {
        sessionName?: string;
        profileType?: string;
        addToAllTrees?: boolean;
    };
}
