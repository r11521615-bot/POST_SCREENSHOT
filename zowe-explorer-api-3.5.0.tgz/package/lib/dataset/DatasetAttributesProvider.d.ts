/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { IProfileLoaded } from "@zowe/imperative";
export type AttributeInfo = {
    title: string;
    reference?: string;
    keys: Map<string, AttributeEntryInfo>;
}[];
export type AttributeEntryInfo = {
    displayName?: string;
    description?: string;
    value: boolean | number | string;
};
export type DsInfo = {
    profile: IProfileLoaded;
    dsName: string;
    attributes?: Record<string, unknown>;
};
export interface IAttributesProvider {
    fetchAttributes(context: DsInfo): AttributeInfo | PromiseLike<AttributeInfo>;
}
export declare class DataSetAttributesProvider {
    private static instance;
    providers: IAttributesProvider[];
    private constructor();
    static getInstance(): DataSetAttributesProvider;
    register(attributeExtender: IAttributesProvider): void;
    fetchAll(context: DsInfo): Promise<AttributeInfo>;
}
