/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import * as vscode from "vscode";
import * as imperative from "@zowe/imperative";
import { ProfilesCache } from "../../profiles/ProfilesCache";
import { DirEntry, FileEntry, FilterEntry, IFileSystemEntry, UriFsInfo } from "../types/abstract";
export declare class FsAbstractUtils {
    /**
     * Returns the metadata for a given URI in the FileSystem.
     * @param uri The "Zowe-compliant" URI to extract info from
     * @returns a metadata type with info about the URI
     */
    static getInfoForUri(uri: vscode.Uri, profilesCache?: ProfilesCache): UriFsInfo;
    static findDocMatchingUri(uri: vscode.Uri): vscode.TextDocument;
    static confirmForUnsavedDoc(uri: vscode.Uri): Promise<boolean>;
    static isDirectoryEntry(entry: IFileSystemEntry): entry is DirEntry;
    static isFileEntry(entry: IFileSystemEntry): entry is FileEntry;
    static isFilterEntry(entry: IFileSystemEntry): entry is FilterEntry;
    /**
     * Executes the provided API getter and translates "missing API/type" failures
     * into a `FileSystemError.Unavailable` error for users and extenders.
     *
     * @param profile The profile used to resolve the API
     * @param apiGetter A callback that returns the API instance (or throws)
     * @param options.apiName Optional friendly name for the API (e.g. "Common API")
     * @param options.registeredTypes Optional list of registered types to short-circuit early
     * @returns The value from `apiGetter` when successful
     * @throws vscode.FileSystemError.Unavailable when the profile type is not registered or the API getter throws a "non-existing" error
     */
    static getApiOrThrowUnavailable<T>(profile: imperative.IProfileLoaded, apiGetter: () => T, options?: {
        apiName?: string;
        registeredTypes?: string[];
    }): T;
}
