/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import * as vscode from "vscode";
import * as imperative from "@zowe/imperative";
import { DirEntry, FileEntry, IFileSystemEntry, ConflictViewSelection, DeleteMetadata, HandleErrorOpts } from "./types";
import { ZosEncoding } from "../tree";
export declare class BaseProvider {
    private readonly FS_PROVIDER_UI_TIMEOUT;
    protected _onDidChangeFileEmitter: vscode.EventEmitter<vscode.FileChangeEvent[]>;
    protected _bufferedEvents: vscode.FileChangeEvent[];
    protected _fireSoonHandle?: NodeJS.Timeout;
    onDidChangeFile: vscode.Event<vscode.FileChangeEvent[]>;
    protected root: DirEntry;
    openedUris: vscode.Uri[];
    onDocClosedEventDisposable: vscode.Disposable;
    protected constructor();
    requestCache: Map<string, Promise<unknown>>;
    /**
     * Compares the data for 2 Uint8Arrays, byte by byte.
     * @param a The first Uint8Array to compare
     * @param b The second Uint8Array to compare
     * @returns `true` if the arrays are equal, `false` otherwise
     */
    static areContentsEqual(a: Uint8Array, b: Uint8Array): boolean;
    /**
     * Action for overwriting the remote contents with local data from the provider.
     * @param uri The URI shown in the diff view
     */
    diffOverwrite(uri: vscode.Uri): Promise<void>;
    /**
     * Action for overwriting the remote contents with local data from the provider.
     * @param uri The URI shown in the diff view
     * @param closeEditor Whether to close the editor after overwriting
     */
    diffOverwrite(uri: vscode.Uri, closeEditor: boolean): Promise<void>;
    /**
     * Action for replacing the local data in the provider with remote contents.
     * @param localUri The local URI shown in the diff view
     */
    diffUseRemote(uri: vscode.Uri): Promise<void>;
    exists(uri: vscode.Uri): boolean;
    /**
     * Removes a local entry from the FS provider if it exists, without making any API requests.
     * @param uri The URI pointing to a local entry in the FS provider
     */
    removeEntry(uri: vscode.Uri): boolean;
    /**
     * Adds an opened URI to the cache so we can see if it has been closed.
     * @param uri the opened URI to keep track of
     */
    cacheOpenedUri(uri: vscode.Uri): void;
    /**
     * Invalidates the data for a file entry at a given URI.
     * Also removes the URI from the opened URI cache.
     * @param uri the URI whose data should be invalidated
     */
    invalidateFileAtUri(uri: vscode.Uri): boolean;
    /**
     * Invalidates the data for a directory entry at a given URI.
     * Also removes the URI from the opened URI cache.
     * @param uri the URI whose data should be invalidated
     */
    invalidateDirAtUri(uri: vscode.Uri): boolean;
    /**
     * Updates the profile reference for all cached entries matching the profile name and type.
     * Called when a profile is updated (reactivated, credentials changed, etc.)
     * @param updatedProfile The updated profile object
     */
    updateProfile(updatedProfile: imperative.IProfileLoaded): void;
    private _updateProfileRecursive;
    /**
     * Returns the encoding for a file entry matching the given URI.
     * @param uri The URI that corresponds to an existing file entry
     * @returns The encoding for the file
     */
    getEncodingForFile(uri: vscode.Uri): ZosEncoding;
    /**
     * Sets the encoding for a file entry matching the given URI.
     * @param uri The URI that corresponds to an existing file entry
     * @param encoding The new encoding for the file entry
     */
    setEncodingForFile(uri: vscode.Uri, encoding: ZosEncoding): void;
    /**
     * Triggers an update for the resource at the given URI to show its latest changes in the editor.
     * @param uri The URI that is open in an editor tab
     */
    protected _updateResourceInEditor(uri: vscode.Uri): Promise<void>;
    /**
     * This function is used to revert changes in the active editor.
     * It can also be used to update an editor with the newest contents of a resource.
     *
     * https://github.com/microsoft/vscode/issues/110493#issuecomment-726542367
     */
    static revertFileInEditor(): Promise<void>;
    /**
     * Update the child path metadata in the provider with the parent's updated entry (recursively).
     * @param entry The parent directory whose children need updated
     */
    protected _updateChildPaths(entry: DirEntry): void;
    private _reopenEditorForRelocatedUri;
    /**
     * Relocates an entry in the provider from `oldUri` to `newUri`.
     * @param oldUri The old, source URI in the provider that needs moved
     * @param newUri The new, destination URI for the file or folder
     * @param newUssPath The new path for this entry in USS
     */
    protected _relocateEntry(oldUri: vscode.Uri, newUri: vscode.Uri, newUssPath: string): Promise<void>;
    protected _getDeleteInfo(uri: vscode.Uri): DeleteMetadata;
    private static onCloseEvent;
    /**
     * Utility functions for conflict management:
     */
    /**
     * Handles the conflict that occurred while trying to write to a file.
     * @param api The API to use during compare/overwrite - must support `getContents` and `uploadFromBuffer` functions
     * @param conflictData The required data for conflict handling
     * @returns The user's action/selection as an enum value
     */
    protected _handleConflict(uri: vscode.Uri, entry: FileEntry): Promise<ConflictViewSelection>;
    /**
     * @deprecated Use `fireSoon` instead. This method will be removed in v4.
     * Internal VSCode function for the FileSystemProvider to fire events from the event queue
     */
    _fireSoon(...events: vscode.FileChangeEvent[]): void;
    /**
     * VSCode function for the FileSystemProvider to fire events from the event queue
     */
    fireSoon(...events: vscode.FileChangeEvent[]): void;
    /**
     * VScode utility functions for entries in the provider:
     */
    /**
     * @deprecated Use `lookup` instead.
     * @param uri The resource URI to lookup within the provider.
     * @param silent `true` to return falsy values if the resource doesn't exist; `false` to throw errors
     * @returns The entry within the provider, or `undefined` if it doesn't exist
     */
    protected _lookup(uri: vscode.Uri, silent?: boolean): IFileSystemEntry | undefined;
    /**
     * @param uri The resource URI to lookup within the provider.
     * @param silent `true` to return falsy values if the resource doesn't exist; `false` to throw errors
     * @returns The entry within the provider, or `undefined` if it doesn't exist
     */
    lookup(uri: vscode.Uri, silent?: boolean): IFileSystemEntry | undefined;
    protected _handleError(err: Error, opts?: HandleErrorOpts): void;
    protected _lookupAsDirectory(uri: vscode.Uri, silent: boolean): DirEntry;
    protected _createFile(uri: vscode.Uri, options?: {
        overwrite: boolean;
    }): FileEntry;
    protected _lookupAsFile(uri: vscode.Uri, opts?: {
        silent?: boolean;
    }): FileEntry;
    /**
     * @deprecated Please use the public version
     */
    protected _lookupParentDirectory(uri: vscode.Uri, silent?: boolean): DirEntry;
    lookupParentDirectory(uri: vscode.Uri, silent?: boolean): DirEntry;
    protected getQueryKey(uri: vscode.Uri): string;
    /**
     * Validates the result of a file system operation to ensure the type matches the requested action.
     * @param result The result object to validate
     * @param uri The URI of the resource being requested
     * @param action The action being performed
     * @returns The validated result
     */
    protected validateResult<T>(result: any, uri: vscode.Uri, action?: "readFile" | "readDirectory" | "stat"): T;
    /**
     * Executes the given operation with reuse logic to avoid duplicate network requests.
     * @param uri The URI of the resource being requested
     * @param options Logic options for key generation, local checks, and execution
     */
    protected executeWithReuse<T>(uri: vscode.Uri, options: {
        keyGenerator: (uri: vscode.Uri) => string;
        checkLocal: () => boolean;
        execute: () => Promise<T>;
        action?: "readFile" | "readDirectory" | "stat";
    }): Promise<T>;
    /**
     * Reverts a dirty document if it exists and is open in the workspace.
     * @param uri The URI to check for a dirty document
     */
    private _revertDirtyDocument;
}
