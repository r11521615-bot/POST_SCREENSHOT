/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import type { Types } from "../..";
import { DirEntry, EntryMetadata, FileEntry } from "./abstract";
import { IProfileLoaded } from "@zowe/imperative";
interface DsEntryProps {
    stats: Types.DatasetStats;
}
export declare const DS_EXTENSION_MAP: Map<string, (string | RegExp)[]>;
export declare enum DsType {
    PdsMember = 0,
    Pds = 1,
    Ps = 2
}
export declare class DsEntry extends FileEntry implements DsEntryProps {
    isMember: boolean;
    metadata: DsEntryMetadata;
    constructor(name: string, isMember?: boolean);
    stats: Types.DatasetStats;
}
export declare class PdsEntry extends DirEntry implements DsEntryProps {
    entries: Map<string, DsEntry>;
    constructor(name: string);
    stats: Types.DatasetStats;
}
export declare class DsEntryMetadata implements EntryMetadata {
    profile: IProfileLoaded;
    path: string;
    constructor(metadata: EntryMetadata);
    /**
     * @returns the data set's file system path without the extension
     */
    extensionRemovedFromPath(): string;
    get dsName(): string;
}
export {};
