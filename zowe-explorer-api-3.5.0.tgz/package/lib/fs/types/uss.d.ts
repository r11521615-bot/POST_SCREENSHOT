/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import * as vscode from "vscode";
import { ConflictData, DirEntry, EntryMetadata, FileEntry } from "./abstract";
import type { Types } from "../..";
export interface UssEntryProps {
    attributes?: Types.FileAttributes;
}
export declare class UssFile extends FileEntry implements UssEntryProps {
    name: string;
    metadata: EntryMetadata;
    type: vscode.FileType;
    wasAccessed: boolean;
    attributes: Types.FileAttributes;
    ctime: number;
    mtime: number;
    size: number;
    conflictData?: ConflictData;
    data?: Uint8Array;
    etag?: string;
    permissions?: vscode.FilePermission;
    constructor(name: string);
}
export declare class UssDirectory extends DirEntry implements UssEntryProps {
    constructor(name?: string);
    attributes: Types.FileAttributes;
}
