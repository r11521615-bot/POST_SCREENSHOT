/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { Duplex } from "stream";
import { IProfileLoaded } from "@zowe/imperative";
import * as vscode from "vscode";
import { ZosEncoding } from "../../tree";
import { ZoweExplorerApiType } from "../../utils/ErrorCorrelator";
export declare enum ZoweScheme {
    DS = "zowe-ds",
    Jobs = "zowe-jobs",
    USS = "zowe-uss"
}
export declare enum ConflictViewSelection {
    UserDismissed = 0,
    Compare = 1,
    Overwrite = 2
}
export type DeleteMetadata = {
    entryToDelete: IFileSystemEntry;
    parent: DirEntry;
    parentUri: vscode.Uri;
};
export declare class BufferBuilder extends Duplex {
    private chunks;
    constructor();
    _write(chunk: any, _encoding: BufferEncoding, callback: (error?: Error) => void): void;
    _read(_size: number): void;
}
export declare const FS_PROVIDER_DELAY = 5;
export type EntryMetadata = {
    profile: IProfileLoaded;
    path: string;
};
export type ConflictData = {
    contents: Uint8Array;
    etag?: string;
    size: number;
};
export interface IFileSystemEntry extends vscode.FileStat {
    name: string;
    metadata: EntryMetadata;
    wasAccessed: boolean;
    data?: Uint8Array;
}
export declare class FileEntry implements IFileSystemEntry {
    name: string;
    metadata: EntryMetadata;
    type: vscode.FileType;
    data?: Uint8Array;
    wasAccessed: boolean;
    ctime: number;
    mtime: number;
    size: number;
    permissions?: vscode.FilePermission;
    /**
     * Remote encoding of the data set
     */
    encoding?: ZosEncoding;
    conflictData?: ConflictData;
    inDiffView?: boolean;
    etag?: string;
    constructor(n: string, readOnly?: boolean);
}
export declare class DirEntry implements IFileSystemEntry {
    name: string;
    metadata: EntryMetadata;
    type: vscode.FileType;
    wasAccessed: boolean;
    ctime: number;
    mtime: number;
    size: number;
    permissions?: vscode.FilePermission;
    entries: Map<string, DirEntry | FileEntry>;
    constructor(n: string);
}
export declare class FilterEntry extends DirEntry {
    filter: Record<string, string>;
    constructor(n: string);
}
export type LocalConflict = {
    fsEntry: FileEntry;
    uri: vscode.Uri;
    content: Uint8Array;
};
export type UriFsInfo = {
    isRoot: boolean;
    slashAfterProfilePos: number;
    profileName: string;
    profile?: IProfileLoaded;
};
export interface HandleErrorOpts {
    retry?: {
        fn: (...args: any[]) => any | PromiseLike<any>;
        args?: any[];
    };
    profileType?: string;
    apiType?: ZoweExplorerApiType;
    templateArgs?: Record<string, string>;
    additionalContext?: string;
}
