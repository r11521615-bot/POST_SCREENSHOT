/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { IJob, IJobFile } from "@zowe/zos-jobs-for-zowe-sdk";
import { DirEntry, EntryMetadata, FileEntry } from "./abstract";
import { FilePermission, FileType } from "vscode";
export type JobFilter = {
    searchId: string;
    owner: string;
    prefix: string;
    status: string;
};
export declare class SpoolEntry extends FileEntry {
    name: string;
    type: FileType;
    wasAccessed: boolean;
    data: Uint8Array;
    permissions?: FilePermission;
    ctime: number;
    mtime: number;
    size: number;
    metadata: EntryMetadata;
    spool?: IJobFile;
    constructor(name: string);
}
export declare class JobEntry extends DirEntry {
    entries: Map<string, SpoolEntry>;
    job?: IJob;
    constructor(name: string);
}
