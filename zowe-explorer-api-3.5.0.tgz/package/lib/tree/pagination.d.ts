/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { TreeItem } from "vscode";
/**
 * Result type expected from the fetch function.
 */
export interface IFetchResult<T, Cursor> {
    items: T[];
    /** The cursor to use for fetching the *next* page, or `undefined` if no more pages exist. */
    nextPageCursor?: Cursor;
    /** Total number of items if known (e.g., from an initial estimate) */
    totalItems?: number;
    /** Number of items to render from the API (might differ from `items.length` if error items are present) */
    returnedRows?: number;
}
export declare class NavigationTreeItem extends TreeItem {
    disabled: boolean;
    constructor(label: string, icon: string, disabled: boolean, command: string, navigateCallback: () => void | PromiseLike<void>);
}
/**
 * Expected function signature for the paginator to leverage. Used to fetch a page of data.
 * @param cursor The cursor indicating where to start fetching (e.g., the last item name of the previous page). Use `undefined` for the first page.
 * @param limit The maximum number of items to fetch for the page.
 * @returns A promise resolving to an object containing the fetched items and an optional cursor for the next page.
 */
export type FetchFn<T, Cursor> = (cursor: Cursor | undefined, limit: number) => IFetchResult<T, Cursor> | Promise<IFetchResult<T, Cursor>>;
/**
 * @brief Provides cursor-based pagination capabilities for a tree view or list of items.
 * It fetches data dynamically page by page using the provided fetch function.
 *
 * @typeParam `T` The type of items to be paginated
 * @typeParam `Cursor` The type of the cursor used to fetch the next page
 */
export declare class Paginator<T, Cursor = string> {
    private currentPageItems;
    private maxItemsPerPage;
    private pageCount;
    private currentPage;
    private currentPageCursor;
    private nextPageCursor;
    private previousPageCursors;
    private hasNextPage;
    private loading;
    private wasInitialized;
    private fetchFn;
    /**
     * Creates a Paginator instance. Call `initialize` to fetch the first page.
     * @param maxItemsPerPage The maximum number of items to display per page. Must be a positive integer.
     * @param fetchFn The function used to fetch pages of data.
     * @throws If {@link maxItemsPerPage} is zero, a negative integer, or a floating-point value.
     */
    constructor(maxItemsPerPage: number, fetchFn: FetchFn<T, Cursor>);
    isInitialized(): boolean;
    private reset;
    /**
     * Initializes the paginator by fetching the first page of data.
     * Should be called after the Paginator is constructed.
     * @throws Error if fetching fails.
     */
    initialize(): Promise<void>;
    /**
     * Fetches and displays the next page of items.
     * @returns The items for the next page.
     * @throws Error if fetching fails or if there is no next page.
     */
    fetchNextPage(): Promise<T[]>;
    /**
     * Fetches and displays the previous page of items.
     * @returns The items for the previous page.
     * @throws Error if fetching fails or if there is no previous page.
     */
    fetchPreviousPage(): Promise<T[]>;
    /**
     * Refetches the data for the current page using the existing cursor.
     * Useful for refreshing the view after data modifications without changing the page.
     * @throws Error if fetching fails.
     */
    refetchCurrentPage(): Promise<void>;
    /**
     * @returns The items currently displayed on the page.
     */
    getCurrentPageItems(): T[];
    /**
     * @returns The current page index (starting at 0)
     */
    getCurrentPageIndex(): number;
    /**
     * @returns The total number of pages
     */
    getPageCount(): number;
    /**
     * @returns The maximum number of items configured per page.
     */
    getMaxItemsPerPage(): number;
    /**
     * @param maxItemsPerPage The new maximum number of items per page.
     * @throws {Error} If {@link maxItemsPerPage} is zero, a negative integer, or a floating-point value.
     */
    setMaxItemsPerPage(maxItemsPerPage: number): void;
    /**
     * @returns `true` if there is potentially a next page available, `false` otherwise.
     */
    canGoNext(): boolean;
    /**
     * @returns `true` if there is a previous page available in the history, `false` otherwise.
     */
    canGoPrevious(): boolean;
    /**
     * @returns `true` if the paginator is currently fetching data, `false` otherwise.
     */
    isLoading(): boolean;
}
