/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import * as imperative from "@zowe/imperative";
import { MessageSeverity } from "./MessageSeverity";
import { Types } from "../Types";
/**
 * Creates an instance of the Imperative logger for extenders to use
 *
 * @export
 * @class IZoweLogger
 */
export declare class IZoweLogger {
    private extensionName;
    LOGGER_CONFIG: Types.Log4JsCfg;
    private log;
    /**
     * Creates an instance of the Imperative logger
     */
    constructor(extensionName: string, loggingPath: string);
    getExtensionName(): string;
    getImperativeLogger(): imperative.Logger;
    /**
     * Log an error message to the Imperative logger.
     * Default severity is DEBUG if not specified.
     */
    logImperativeMessage(message: string, severity?: MessageSeverity): void;
}
