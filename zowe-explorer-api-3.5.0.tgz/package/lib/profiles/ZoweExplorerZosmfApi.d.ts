/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import * as imperative from "@zowe/imperative";
import * as zosconsole from "@zowe/zos-console-for-zowe-sdk";
import * as zosfiles from "@zowe/zos-files-for-zowe-sdk";
import * as zosjobs from "@zowe/zos-jobs-for-zowe-sdk";
import * as zostso from "@zowe/zos-tso-for-zowe-sdk";
import * as zosuss from "@zowe/zos-uss-for-zowe-sdk";
import { MainframeInteraction } from "../extend/MainframeInteraction";
import { Types } from "../Types";
import { IDataSetCount } from "../dataset/IDataSetCount";
/**
 * Implementations of Zowe Explorer API for z/OSMF profiles
 */ export declare namespace ZoweExplorerZosmf {
    /**
     * An implementation of the Zowe Explorer API Common interface for zOSMF.
     */
    class CommonApi implements MainframeInteraction.ICommon {
        profile?: imperative.IProfileLoaded;
        static getProfileTypeName(): string;
        private session;
        constructor(profile?: imperative.IProfileLoaded);
        getProfileTypeName(): string;
        getSessionFromCommandArgument(cmdArgs: imperative.ICommandArguments): imperative.Session;
        getSession(profile?: imperative.IProfileLoaded): imperative.Session;
        static getCommandArgs(profile: imperative.IProfileLoaded): imperative.ICommandArguments;
        private _getSession;
        getStatus(validateProfile?: imperative.IProfileLoaded, profileType?: string): Promise<string>;
        getTokenTypeName(): string;
        login(session: imperative.Session): Promise<string>;
        logout(session: imperative.Session): Promise<void>;
    }
    /**
     * An implementation of the Zowe Explorer USS API interface for zOSMF.
     */
    class UssApi extends CommonApi implements MainframeInteraction.IUss {
        fileList(ussFilePath: string, options?: zosfiles.IUSSListOptions): Promise<zosfiles.IZosFilesResponse>;
        isFileTagBinOrAscii(ussFilePath: string): Promise<boolean>;
        getContents(inputFilePath: string, options: zosfiles.IDownloadSingleOptions): Promise<zosfiles.IZosFilesResponse>;
        downloadDirectory(ussDirectoryPath: string, fileOptions?: zosfiles.IDownloadOptions, listOptions?: zosfiles.IUSSListOptions): Promise<zosfiles.IZosFilesResponse>;
        copy(outputPath: string, options?: Omit<object, "request">): Promise<Buffer>;
        move(oldPath: string, newPath: string): Promise<void>;
        uploadFromBuffer(buffer: Buffer, filePath: string, options?: zosfiles.IUploadOptions): Promise<zosfiles.IZosFilesResponse>;
        putContent(inputFilePath: string, ussFilePath: string, options: zosfiles.IUploadOptions): Promise<zosfiles.IZosFilesResponse>;
        updateAttributes(ussPath: string, attributes: Partial<Types.FileAttributes>): Promise<zosfiles.IZosFilesResponse>;
        uploadDirectory(inputDirectoryPath: string, ussDirectoryPath: string, options?: zosfiles.IUploadOptions): Promise<zosfiles.IZosFilesResponse>;
        create(ussPath: string, type: string, mode?: string): Promise<zosfiles.IZosFilesResponse>;
        delete(ussPath: string, recursive?: boolean): Promise<zosfiles.IZosFilesResponse>;
        rename(currentUssPath: string, newUssPath: string): Promise<zosfiles.IZosFilesResponse>;
        getTag(ussPath: string): Promise<string>;
    }
    /**
     * An implementation of the Zowe Explorer MVS API interface for zOSMF.
     */
    class MvsApi extends CommonApi implements MainframeInteraction.IMvs {
        dataSet(filter: string, options?: zosfiles.IListOptions): Promise<zosfiles.IZosFilesResponse>;
        allMembers(dataSetName: string, options?: zosfiles.IListOptions): Promise<zosfiles.IZosFilesResponse>;
        getContents(dataSetName: string, options?: zosfiles.IDownloadSingleOptions): Promise<zosfiles.IZosFilesResponse>;
        downloadAllMembers(dataSetName: string, options?: zosfiles.IDownloadOptions): Promise<zosfiles.IZosFilesResponse>;
        uploadFromBuffer(buffer: Buffer, dataSetName: string, options?: zosfiles.IUploadOptions): Promise<zosfiles.IZosFilesResponse>;
        putContents(inputFilePath: string, dataSetName: string, options?: zosfiles.IUploadOptions): Promise<zosfiles.IZosFilesResponse>;
        createDataSet(dataSetType: zosfiles.CreateDataSetTypeEnum, dataSetName: string, options?: Partial<zosfiles.ICreateDataSetOptions>): Promise<zosfiles.IZosFilesResponse>;
        createDataSetMember(dataSetName: string, options?: zosfiles.IUploadOptions): Promise<zosfiles.IZosFilesResponse>;
        allocateLikeDataSet(dataSetName: string, likeDataSetName: string): Promise<zosfiles.IZosFilesResponse>;
        copyDataSetMember({ dsn: fromDataSetName, member: fromMemberName }: zosfiles.IDataSet, { dsn: toDataSetName, member: toMemberName }: zosfiles.IDataSet, options?: zosfiles.ICopyDatasetOptions): Promise<zosfiles.IZosFilesResponse>;
        renameDataSet(currentDataSetName: string, newDataSetName: string): Promise<zosfiles.IZosFilesResponse>;
        renameDataSetMember(dataSetName: string, oldMemberName: string, newMemberName: string): Promise<zosfiles.IZosFilesResponse>;
        hMigrateDataSet(dataSetName: string): Promise<zosfiles.IZosFilesResponse>;
        hRecallDataSet(dataSetName: string): Promise<zosfiles.IZosFilesResponse>;
        deleteDataSet(dataSetName: string, options?: zosfiles.IDeleteDatasetOptions): Promise<zosfiles.IZosFilesResponse>;
        dataSetsMatchingPattern(filter: string[], options?: zosfiles.IDsmListOptions): Promise<zosfiles.IZosFilesResponse>;
        copyDataSet(fromDataSetName: string, toDataSetName: string, enq?: string, replace?: boolean): Promise<zosfiles.IZosFilesResponse>;
        searchDataSets(searchOptions: zosfiles.ISearchOptions): Promise<zosfiles.ISearchResponse>;
        copyDataSetCrossLpar(toDataSetName: string, toMemberName: string, options: zosfiles.ICrossLparCopyDatasetOptions, sourceprofile: imperative.IProfileLoaded): Promise<zosfiles.IZosFilesResponse>;
        getCount(dataSetPatterns: string[]): Promise<IDataSetCount>;
    }
    /**
     * An implementation of the Zowe Explorer JES API interface for zOSMF.
     */
    class JesApi extends CommonApi implements MainframeInteraction.IJes {
        getJobsByParameters(params: zosjobs.IGetJobsParms): Promise<zosjobs.IJob[]>;
        getJob(jobid: string): Promise<zosjobs.IJob>;
        getSpoolFiles(jobname: string, jobid: string): Promise<zosjobs.IJobFile[]>;
        downloadSpoolContent(parms: zosjobs.IDownloadAllSpoolContentParms): Promise<void>;
        downloadSingleSpool(parms: zosjobs.IDownloadSpoolContentParms): Promise<void>;
        getSpoolContentById(jobname: string, jobid: string, spoolId: number, encoding?: string): Promise<string>;
        getJclForJob(job: zosjobs.IJob): Promise<string>;
        submitJcl(jcl: string, internalReaderRecfm?: string, internalReaderLrecl?: string): Promise<zosjobs.IJob>;
        submitJob(jobDataSet: string): Promise<zosjobs.IJob>;
        deleteJob(jobname: string, jobid: string): Promise<void>;
        deleteJobWithInfo(jobname: string, jobid: string): Promise<undefined | zosjobs.IJobFeedback>;
        cancelJob(job: zosjobs.IJob): Promise<boolean>;
        supportSpoolPagination(): boolean;
    }
    /**
     * An implementation of the Zowe Explorer Command API interface for zOSMF.
     */
    class CommandApi extends CommonApi implements MainframeInteraction.ICommand {
        issueTsoCommandWithParms(command: string, parms: zostso.IStartTsoParms, useNewTsoApis?: boolean): Promise<zostso.IIssueResponse>;
        issueMvsCommand(command: string, consoleName?: string): Promise<zosconsole.IConsoleResponse>;
        issueUnixCommand(command: string, cwd: string, sshSession: zosuss.SshSession): Promise<string>;
        sshProfileRequired?(): boolean;
    }
}
