/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
/**
 * Interfaces for anything related to validation for Zowe profiles
 */
export declare namespace Validation {
    interface IValidationUrl {
        valid: boolean;
        protocol: string;
        host: string;
        port: number;
    }
    interface IValidationProfile {
        status: string;
        name: string;
    }
    interface IValidationSetting {
        name: string;
        setting: boolean;
    }
    enum ValidationType {
        UNVERIFIED = 1,
        VALID = 0,
        INVALID = -1
    }
    enum EventType {
        CREATE = 0,
        UPDATE = 1,
        DELETE = 2
    }
}
