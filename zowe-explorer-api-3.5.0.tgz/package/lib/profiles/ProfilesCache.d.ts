/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import * as imperative from "@zowe/imperative";
import type { IRegisterClient } from "../extend/IRegisterClient";
import { Validation } from "./Validation";
import { Types } from "../Types";
export declare class ProfilesCache {
    protected log: imperative.Logger;
    protected cwd?: string;
    private profileInfo;
    profilesForValidation: Validation.IValidationProfile[];
    profilesValidationSetting: Validation.IValidationSetting[];
    allProfiles: imperative.IProfileLoaded[];
    /**
     * @deprecated
     * Use ProfilesCache.seesionProfileTypeConfigurations for Zowe Explorer VS Code session registered and Zowe core types list of meta-data.
     * */
    profileTypeConfigurations: imperative.ICommandProfileTypeConfiguration[];
    static sessionProfileTypeConfigurations: imperative.ICommandProfileTypeConfiguration[];
    protected allTypes: string[];
    protected allExternalTypes: Set<string>;
    protected profilesByType: Map<string, imperative.IProfileLoaded[]>;
    protected defaultProfileByType: Map<string, imperative.IProfileLoaded>;
    protected overrideWithEnv: boolean;
    constructor(log: imperative.Logger, cwd?: string);
    static requireKeyring(this: void): NodeJS.Module;
    /**
     * Adds profile type meta-data to array for future use with team configuration actions,
     * ie. Zowe Explorer uses upon extender registration in VS Code.
     *
     * @param {imperative.ICommandProfileTypeConfiguration[]} extendermetadata Profile type meta-data used with Zowe team configurations
     *
     * @returns {void}
     */
    addToConfigArray(extendermetadata: imperative.ICommandProfileTypeConfiguration[]): void;
    /**
     * Returns an array of Zowe Explorer registered profile types and core Zowe supported profile types meta-data ,
     * used with Zowe team configuration actions.
     *
     * @returns {imperative.ICommandProfileTypeConfiguration[]}
     */
    static getConfigArray(): imperative.ICommandProfileTypeConfiguration[];
    /**
     * Consider using the static ProfilesCache.getConfigArray() instead as `sessionProfileTypeConfigurations` (return value) is a static property.
     * @returns {imperative.ICommandProfileTypeConfiguration[]}
     */
    getConfigArray(): imperative.ICommandProfileTypeConfiguration[];
    /**
     * Get the credential manager options from imperative.json
     * @returns Record<string, any> | undefined the credential manager options, or undefined if not specified
     */
    static getCredentialManagerOptions(): Record<string, any> | undefined;
    getProfileInfo(_envTheia?: boolean): Promise<imperative.ProfileInfo>;
    /**
     * Loads the named profile from allProfiles
     *
     * @param {string} name Name of Profile
     * @param {string} type Type of Profile, optional
     * @param {boolean} optional Whether or not to throw an error if profile is not found
     *
     * @throws {Error} Throws an error if profile is not found (unless optional is true)
     * @returns {IProfileLoaded}
     */
    loadNamedProfile(name: string, type?: string, optional?: boolean): imperative.IProfileLoaded;
    /**
     * Updates profile in allProfiles array and if default updates defaultProfileByType
     * @deprecated Use `updateCachedProfile` instead
     * @param {string} profileLoaded
     * @returns {void}
     */
    updateProfilesArrays(profileLoaded: imperative.IProfileLoaded): void;
    updateCachedProfile(profileLoaded: imperative.IProfileLoaded, profileNode?: Types.IZoweNodeType, _zeRegister?: Types.IApiRegisterClient): void;
    /**
     * This returns default profile by type from defaultProfileByType
     *
     * @param {string} type Name of Profile, defaults to "zosmf" if nothing passed.
     *
     * @returns {IProfileLoaded}
     */
    getDefaultProfile(type?: string): imperative.IProfileLoaded;
    /**
     * Gets default Profile attributes from imperative
     *
     * @param {ProfileInfo} mProfileInfo
     * @param {string} profileType Type of Profile
     *
     * @returns {IProfAttrs}
     */
    getDefaultConfigProfile(mProfileInfo: imperative.ProfileInfo, profileType: string): imperative.IProfAttrs;
    /**
     * Gets array of profiles by type
     *
     * @param {string} type Type of Profile, defaults to "zosmf" if nothing passed.
     *
     * @returns {IProfileLoaded[]}
     */
    getProfiles(type?: string): imperative.IProfileLoaded[];
    /**
     * Used for extenders to register with Zowe Explorer that do not need their
     * profile type in the existing MVS, USS, and JES
     *
     * @param {string} profileTypeName Type of Profile
     *
     * @returns {void}
     */
    registerCustomProfilesType(profileTypeName: string): void;
    refresh(apiRegister?: IRegisterClient): Promise<void>;
    /**
     * Used to check validity of a profile's certfile used for authentication
     *
     * @param {string} certFile Path to certFile from profile
     *
     * @returns {boolean} True if certFile is valid and false otherwise
     */
    isCertFileValid(certFile: string): boolean;
    validateAndParseUrl(newUrl: string): Validation.IValidationUrl;
    /**
     * get array of profile types
     * @returns string[]
     */
    getAllTypes(): string[];
    /**
     * get array of Profile names by type
     * @param type  profile type
     * @returns string[]
     */
    getNamesForType(type: string): Promise<string[]>;
    /**
     * get array of IProfileLoaded by type
     * @param type profile type
     * @returns IProfileLoaded[]
     */
    fetchAllProfilesByType(type: string): Promise<imperative.IProfileLoaded[]>;
    /**
     * get array of IProfileLoaded for all profiles
     * @returns IProfileLoaded[]
     */
    fetchAllProfiles(): Promise<imperative.IProfileLoaded[]>;
    /**
     * Direct load and return of particular IProfileLoaded
     * @param type profile type
     * @param name profile name
     * @returns IProfileLoaded
     */
    directLoad(type: string, name: string): Promise<imperative.IProfileLoaded | undefined>;
    getProfileFromConfig(profileName: string, profileType?: string): Promise<imperative.IProfAttrs | undefined>;
    getLoadedProfConfig(profileName: string, profileType?: string): Promise<imperative.IProfileLoaded | undefined>;
    getBaseProfile(): imperative.IProfileLoaded | undefined;
    /**
     * Retrieves the base profile from Imperative to use for log in/out. If a
     * nested profile name is specified (e.g. "lpar.zosmf"), then its parent
     * profile is returned unless token is already stored in the base profile.
     * @param profileName Name of profile that was selected in the tree
     * @returns IProfileLoaded object or undefined if no profile was found
     */
    fetchBaseProfile(profileName?: string): Promise<imperative.IProfileLoaded | undefined>;
    /**
     * This returns true or false depending on if credentials are stored securely.
     *
     * @returns {boolean}
     */
    isCredentialsSecured(): Promise<boolean>;
    getProfileLoaded(profileName: string, profileType: string, profile: imperative.IProfile): imperative.IProfileLoaded;
    static convertV1ProfToConfig(profileInfo: imperative.ProfileInfo, deleteV1Profs?: boolean): Promise<imperative.IConvertV1ProfResult>;
    static getProfileSessionWithVscProxy(session: imperative.Session): imperative.Session;
    getCoreProfileTypes(): imperative.IProfileTypeConfiguration[];
    protected getMergedAttrs(mProfileInfo: imperative.ProfileInfo, profAttrs: imperative.IProfAttrs): imperative.IProfile;
    private getAllProfileTypes;
    private getParentProfileForToken;
    shouldRemoveTokenFromProfile(profile: imperative.IProfileLoaded, baseProfile: imperative.IProfileLoaded): boolean;
    updateBaseProfileFileLogin(profile: imperative.IProfileLoaded, updProfile: imperative.IProfile, forceUpdate?: boolean): Promise<void>;
    updateBaseProfileFileLogout(profile: imperative.IProfileLoaded): Promise<void>;
    checkForEnvVarAndUpdate(): void;
}
