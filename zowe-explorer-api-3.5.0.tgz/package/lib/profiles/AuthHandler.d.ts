/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import type * as imperative from "@zowe/imperative";
import type { Mutex } from "async-mutex";
import type { AuthPromptParams, IAuthMethods, ProfileLike } from "../vscode/session/AuthHandler";
export type { AuthPromptParams, IAuthMethods, ProfileLike };
export declare class AuthCancelledError extends Error {
    readonly profileName: string;
    constructor(profileName: string, message?: string);
}
export declare class AuthHandler {
    static get authPromptLocks(): Map<string, Mutex>;
    static set authPromptLocks(value: Map<string, Mutex>);
    static get profileLocks(): Map<string, Mutex>;
    static set profileLocks(value: Map<string, Mutex>);
    static get authCancelledProfiles(): Set<string>;
    static set authCancelledProfiles(value: Set<string>);
    static get authFlows(): Map<string, Promise<void>>;
    static set authFlows(value: Map<string, Promise<void>>);
    static get sequentialLocks(): Map<string, Mutex>;
    static set sequentialLocks(value: Map<string, Mutex>);
    static get parallelEnabledProfiles(): Set<string>;
    static set parallelEnabledProfiles(value: Set<string>);
    static get enabledProfileTypes(): Set<string>;
    static set enabledProfileTypes(value: Set<string>);
    static setAuthCancelled(profile: ProfileLike, wasCancelled: boolean): void;
    static wasAuthCancelled(profile: ProfileLike): boolean;
    static enableLocksForType(type: string): void;
    static disableLocksForType(type: string): void;
    static getSessFromProfile(profile: imperative.IProfileLoaded): imperative.Session;
    static sessTypeFromSession(session: imperative.Session): imperative.SessConstants.AUTH_TYPE_CHOICES;
    static sessTypeFromProfile(profile: imperative.IProfileLoaded): imperative.SessConstants.AUTH_TYPE_CHOICES;
    /**
     * @deprecated Use AuthHandler.sessTypeFromProfile and/or AuthHandler.sessTypeFromSession, which will adhere to authOrder.
     */
    static isUsingTokenAuth(profileProps: string[], baseProfileProps?: string[]): boolean;
    static unlockProfile(profile: ProfileLike, refreshResources?: boolean): void;
    static promptForAuthentication(profile: ProfileLike, params: AuthPromptParams): Promise<boolean>;
    static lockProfile(profile: ProfileLike, authOpts?: AuthPromptParams): Promise<boolean>;
    static enableSequentialRequests(profile: ProfileLike): void;
    static disableSequentialRequests(profile: ProfileLike): void;
    static areSequentialRequestsEnabled(profile: ProfileLike): boolean;
    static runSequentialIfEnabled<T>(profile: ProfileLike, action: () => Promise<T>): Promise<T>;
    static waitForUnlock(profile: ProfileLike): Promise<void>;
    static unlockAllProfiles(): void;
    static isProfileLocked(profile: ProfileLike): boolean;
    static getActiveAuthFlow(profile: ProfileLike): Promise<void> | undefined;
    static getOrCreateAuthFlow(profile: ProfileLike, authOpts: AuthPromptParams): Promise<void>;
}
