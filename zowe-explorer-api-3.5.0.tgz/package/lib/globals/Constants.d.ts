/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
/**
 * Global variables accessed across the API
 */
export declare namespace Constants {
    const ZOWE_EXPLORER = "Zowe Explorer";
    const SCS_ZOWE_PLUGIN = "Zowe-Plugin";
    const SCS_ZOWE_CLI_V2 = "Zowe";
    const SCS_BRIGHTSIDE = "@brightside/core";
    const SCS_ZOWE_CLI = "@zowe/cli";
    const SCS_BROADCOM_PLUGIN = "Broadcom-Plugin";
    const SETTINGS_SCS_DEFAULT = "Zowe";
    const CONTEXT_PREFIX = "_";
    const DEFAULT_PORT = 443;
    const DOUBLE_CLICK_SPEED_MS = 500;
    const DEFAULT_ITEMS_PER_PAGE = 100;
    const PERM_VALUES: {
        r: number;
        w: number;
        x: number;
    };
}
